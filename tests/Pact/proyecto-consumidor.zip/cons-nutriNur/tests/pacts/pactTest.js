const { Pact } = require('@pact-foundation/pact');
const { expect } = require('chai');
const path = require('path');
const axios = require('axios');

const provider = new Pact({
  consumer: "Frontend", // Cliente (quien usa la API)
  provider: "Backend",  // Servidor (quien expone la API)
  port: 1234,  // Puerto donde simularemos la API
  log: path.resolve(__dirname, 'pact.log'),
  dir: path.resolve(__dirname, 'pacts'),
  spec: 2,
});

describe('Pact Contract Test', () => {
  before(() => provider.setup());
  after(() => provider.finalize());

  it('Debería obtener un paciente por un ID dado', async () => {
    await provider.addInteraction({
      state: "Existe un paciente con ID dado",
      uponReceiving: "Una solicitud GET a /paciente/61a9804c-299b-4dbc-9473-c8f97014f6b3",
      withRequest: {
        method: "GET",
        path: "/paciente/61a9804c-299b-4dbc-9473-c8f97014f6b3",
      },
      willRespondWith: {
        status: 200,
        headers: { "Content-Type": "application/json" },
        body: { id: "61a9804c-299b-4dbc-9473-c8f97014f6b3", nombre: "luz", fechaNacimiento: "09/02/2005" },
      },
    });

    // Llamamos al servicio simulado
    const response = await axios.get("http://localhost:1234/paciente/61a9804c-299b-4dbc-9473-c8f97014f6b3");

    // Validamos respuesta
    expect(response.status).to.equal(200);
    expect(response.data).to.deep.equal({
      id: "61a9804c-299b-4dbc-9473-c8f97014f6b3",
      nombre: "luz",
      fechaNacimiento: "09/02/2005",
    });

    // Verificamos que el contrato se cumpla
    await provider.verify();
  });

  it('Debería guardar un paciente', async () => {
    await provider.addInteraction({
      state: "Debería guardar un paciente",
      uponReceiving: "Una solicitud POST a /paciente/add",
      withRequest: {
        method: "POST",
        path: "/paciente/add",
        headers: { "Content-Type": "application/json" },
        body: {
          nombre: "Juan Pérez",
          fechaNacimiento: "2003-01-01"
        },
      },
      willRespondWith: {
        status: 200,
        headers: { "Content-Type": "application/json" },
        body: {"message":"Paciente creado"},
      },
    });

    // Llamamos al servicio simulado con POST
    const response = await axios.post("http://localhost:1234/paciente/add", {
      nombre: "Juan Pérez",
      fechaNacimiento: "2003-01-01"
    }, { headers: { "Content-Type": "application/json" } });

    // Validamos respuesta
    expect(response.status).to.equal(200);
    expect(response.data).to.deep.equal({
      "message":"Paciente creado"
    });

    // Verificamos que el contrato se cumpla
    await provider.verify();
  });
});
