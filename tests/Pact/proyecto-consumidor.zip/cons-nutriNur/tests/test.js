"const assert = require('assert'); describe('Prueba inicial', function() { it('Debe retornar verdadero', function() { assert.strictEqual(true, true); }); });" 
